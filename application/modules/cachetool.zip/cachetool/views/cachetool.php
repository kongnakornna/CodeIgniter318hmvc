<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
echo'<hr>';
echo '<pre>key=>'; print_r($key); echo '</pre>';  
echo '<pre>lang=>'; print_r($lang); echo '</pre>';  
echo '<pre>timecache=>'; print_r($timecache); echo '</pre>';    
?>
 