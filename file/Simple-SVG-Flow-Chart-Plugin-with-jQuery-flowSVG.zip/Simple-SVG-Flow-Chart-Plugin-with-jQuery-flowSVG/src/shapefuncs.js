        shapeFuncs = {
            decision: decision,
            finish: finish,
            process: process
        };