        return {
            config: setParams,
            draw: setRoot,
            shapes: layoutShapes
        };
    }());